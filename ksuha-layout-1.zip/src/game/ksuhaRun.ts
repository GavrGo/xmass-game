// Движок Ksuha Run: физика, препятствия, монеты, погоня, столкновения и рисование на canvas.
// React-экран (screens/KsuhaRun.tsx) только запускает его и показывает меню и результат.
// Все числа берутся из config.ts (раздел КСЮХА_РАН).
import { КСЮХА_РАН as К, КлючСложности, ЭффектЗвука } from "../config";
import { Т } from "../texts";
import { бонусЗарплатыПроц } from "./effects";

const ИГРОК = { x: 120, w: 40, h: 52 }; // позиция и размер героини (в «логических» пикселях)

export type Фаза = "menu" | "playing" | "over";

interface Препятствие { x: number; size: number; картинка: number; вытяжка: [number, number]; passed: boolean }
interface Монета { x: number; h: number; emoji: string; ценность: number; взята: boolean }
interface Всплывашка { x: number; y: number; text: string; t: number }
interface Снежинка { x: number; y: number; r: number; v: number }

// Картинка фишки (assets/icons/slot-chip.png) для монет и счётчика на canvas
const чипКартинка: HTMLImageElement | null = typeof Image !== "undefined" ? Object.assign(new Image(), { src: "/assets/icons/slot-chip.png" }) : null;
const чипГотов = () => !!чипКартинка && чипКартинка.complete && чипКартинка.naturalWidth > 0;

const случайно = (a: number, b: number) => a + Math.random() * (b - a);

const ПУТЬ_АССЕТОВ = "/assets/ksuha/";
const загрузить = (путь: string) => Object.assign(new Image(), { src: путь });
const готова = (img: HTMLImageElement) => img.complete && img.naturalWidth > 0;
const фонИмг = загрузить(ПУТЬ_АССЕТОВ + "BG.png");
const дорогаИмг = загрузить(ПУТЬ_АССЕТОВ + "Road.png");
const ксюхаИмг = загрузить(ПУТЬ_АССЕТОВ + "Ksuha.png");
const мэнИмг = загрузить(ПУТЬ_АССЕТОВ + "Man.png");
const барьеры = К.препятствия.картинки.map((f) => загрузить(ПУТЬ_АССЕТОВ + f));
const подарокКартинка = загрузить("/assets/icons/slot-gift.png");

function спрайт(ctx: CanvasRenderingContext2D, img: HTMLImageElement, cx: number, низ: number, высота: number, угол = 0) {
  if (!готова(img)) return;
  const ширина = высота * img.naturalWidth / img.naturalHeight;
  ctx.save();
  ctx.translate(cx, низ);
  if (угол) ctx.rotate(угол);
  ctx.drawImage(img, -ширина / 2, -высота, ширина, высота);
  ctx.restore();
}

/** Рисует эмодзи. зеркало = true разворачивает его вправо (эмодзи бегут влево по умолчанию). */
function эмодзи(ctx: CanvasRenderingContext2D, символ: string, cx: number, низ: number, size: number, зеркало = false, угол = 0) {
  ctx.save();
  ctx.translate(cx, низ);
  if (угол) ctx.rotate(угол);
  if (зеркало) ctx.scale(-1, 1);
  ctx.font = `${size}px serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "bottom";
  ctx.fillText(символ, 0, 0);
  ctx.restore();
}

export class КсюхаРанДвижок {
  // --- размер экрана и мира ---
  масштаб = 1;
  мирШирина: number = К.мир.минШирина;
  мирВысота = 400;
  safeTopCss = 0;        // верхний отступ под кнопки Telegram (в css-пикселях)

  ключСложности: КлючСложности = "medium";
  // Хук для звуков: экран подключает сюда звуковой менеджер (звук прыжка, монеты, поражения)
  событие: ((имя: ЭффектЗвука) => void) | null = null;

  // --- героиня ---
  подъём = 0;            // высота над землёй
  vy = 0;                // вертикальная скорость (вверх — плюс)
  прыжков = 0;
  история: { t: number; h: number }[] = []; // как высоко она была: по этому прыгает преследователь

  // --- мир ---
  препятствия: Препятствие[] = [];
  монеты: Монета[] = [];
  всплывашки: Всплывашка[] = [];
  снег: Снежинка[] = [];
  скорость: number = К.скорость.старт;
  смещение = 0;
  смещениеФона = 0;
  фазаБега = 0;

  // --- счёт ---
  пройдено = 0;
  монетСобрано = 0;
  суммаМонет = 0;        // сумма ценности собранных монет (в фишках, может быть дробной)
  время = 0;
  лимит = 0;
  осталось = 0;
  дозаПоявления = 1.1;
  дозаМонеты = 2;
  закончена = false;
  причина: "crash" | "time" | null = null;
  послеКонца = 0;

  constructor(лимитСек: number) { this.сброс(лимитСек, "medium"); }

  get земля() { return this.мирВысота * К.мир.доляВысотыЗемли; }

  /** Подгоняем мир под размер экрана (css-пиксели). */
  задатьРазмер(w: number, h: number, safeTop: number) {
    this.масштаб = Math.min(w / К.мир.минШирина, h / К.мир.минВысота);
    this.мирШирина = w / this.масштаб;
    this.мирВысота = h / this.масштаб;
    this.safeTopCss = safeTop;
  }

  /** Начать всё заново на выбранной сложности. */
  сброс(лимитСек: number, сложность: КлючСложности) {
    this.ключСложности = сложность;
    this.подъём = 0; this.vy = 0; this.прыжков = 0; this.история = [];
    this.препятствия = []; this.монеты = []; this.всплывашки = [];
    this.скорость = К.скорость.старт * К.сложности[сложность].множительСкорости;
    this.пройдено = 0; this.монетСобрано = 0; this.суммаМонет = 0;
    this.время = 0; this.лимит = лимитСек; this.осталось = лимитСек;
    this.дозаПоявления = 1.1; this.дозаМонеты = случайно(1.5, 3);
    this.закончена = false; this.причина = null; this.послеКонца = 0;
    this.смещение = 0; this.смещениеФона = 0; this.фазаБега = 0;
    this.снег = Array.from({ length: 40 }, () => ({
      x: случайно(0, this.мирШирина), y: случайно(0, this.земля), r: случайно(1, 3), v: случайно(15, 45),
    }));
  }

  /** Прыжок (тап / пробел). Второй прыжок в воздухе — если разрешён в config. */
  прыжок() {
    if (this.закончена || this.прыжков >= К.физика.максПрыжковПодряд) return;
    this.vy = this.прыжков === 0 ? К.физика.силаПрыжка : К.физика.силаВторогоПрыжка;
    this.прыжков++;
    this.событие?.("прыжок");
  }

  /** Самая большая высота, до которой реально допрыгнуть (нужна, чтобы монеты были достижимы). */
  private достижимаяВысота() {
    const g = К.физика.гравитация;
    const первый = (К.физика.силаПрыжка ** 2) / (2 * g);
    if (К.физика.максПрыжковПодряд < 2) return первый;
    return первый + 0.8 * ((К.физика.силаВторогоПрыжка ** 2) / (2 * g));
  }

  /** Только снег — для фона в меню. */
  обновитьСнег(dt: number, скоростьМира: number) {
    for (const с of this.снег) {
      с.x -= (скоростьМира * 0.25 + с.v) * dt;
      с.y += с.v * 0.4 * dt;
      if (с.x < 0) с.x += this.мирШирина;
      if (с.y > this.земля) с.y = 0;
    }
  }

  /** Один шаг игры. dt — сколько секунд прошло с прошлого кадра. */
  обновить(dt: number) {
    if (this.закончена) return;
    const сл = К.сложности[this.ключСложности];
    this.время += dt;

    // Таймер (мягкий лимит)
    if (this.лимит > 0) {
      this.осталось = Math.max(0, this.лимит - this.время);
      if (this.осталось <= 0) { this.закончена = true; this.причина = "time"; return; }
    }

    // Скорость растёт со временем
    // «Бесконечный» режим разгоняется быстрее (множительРоста)
    this.скорость = Math.min(К.скорость.максимум, К.скорость.старт + К.скорость.прирост * (сл.множительРоста ?? 1) * this.время) * сл.множительСкорости;

    // Физика прыжка
    this.vy -= К.физика.гравитация * dt;
    this.подъём += this.vy * dt;
    if (this.подъём <= 0) { this.подъём = 0; this.vy = 0; this.прыжков = 0; }

    // История высот: преследователь повторяет прыжки с задержкой = дистанция / скорость
    this.история.push({ t: this.время, h: this.подъём });
    const лаг = К.погоня.дистанция / this.скорость;
    while (this.история.length > 1 && this.история[1].t <= this.время - лаг) this.история.shift();

    // Движение фона
    this.смещение = (this.смещение + this.скорость * dt) % 100000;
    this.смещениеФона = (this.смещениеФона + this.скорость * К.вид.параллакс * dt) % 100000;
    this.фазаБега += dt * 14;
    this.обновитьСнег(dt, this.скорость);

    // Появление препятствий
    this.дозаПоявления -= dt;
    if (this.дозаПоявления <= 0) {
      const п = К.препятствия;
      this.препятствия.push({
        x: this.мирШирина + 20,
        size: Math.round(случайно(п.минРазмер, п.максРазмер)),
        картинка: Math.floor(Math.random() * п.картинки.length),
        вытяжка: [случайно(0.85, 1.15), случайно(0.85, 1.15)],
        passed: false,
      });
      this.дозаПоявления = случайно(п.паузаМинСек, п.паузаМаксСек) * сл.множительПауз;
    }

    // Появление монет (с паузами, не кучно, и не прямо на препятствии)
    this.дозаМонеты -= dt;
    if (this.дозаМонеты <= 0) {
      const м = К.монеты;
      const стартX = this.мирШирина + 20;
      const рядом = this.препятствия.some((о) => Math.abs(о.x - стартX) < 130);
      if (рядом) {
        this.дозаМонеты = 0.3; // подождём, пока препятствие уедет
      } else {
        const потолок = Math.min(м.высотаМакс, this.достижимаяВысота() - 25);
        const вид = this.выбратьВидМонеты();
        this.монеты.push({ x: стартX, h: случайно(м.высотаМин, Math.max(м.высотаМин, потолок)), emoji: вид.эмодзи, ценность: вид.ценность, взята: false });
        const вМинуту = случайно(м.минВМинуту, м.максВМинуту);
        this.дозаМонеты = Math.max(м.минПаузаСек, (60 / вМинуту) * случайно(0.7, 1.3));
      }
    }

    const зем = this.земля;
    const пб = К.поблажкаХитбокса;

    // Препятствия: движение, счёт, столкновение
    for (const о of this.препятствия) {
      о.x -= this.скорость * dt;
      if (!о.passed && о.x + о.size < ИГРОК.x) { о.passed = true; this.пройдено++; }

      const иЛево = ИГРОК.x + пб, иПраво = ИГРОК.x + ИГРОК.w - пб;
      const иНиз = зем - this.подъём - пб, иВерх = зем - this.подъём - ИГРОК.h + пб;
      const оЛево = о.x + пб, оПраво = о.x + о.size - пб;
      const оВерх = зем - о.size + пб;
      if (иПраво > оЛево && иЛево < оПраво && иНиз > оВерх && иВерх < зем) {
        this.событие?.("поражение");
        this.закончена = true; this.причина = "crash"; return;
      }
    }
    this.препятствия = this.препятствия.filter((о) => о.x > -о.size - 20);

    // Монеты: движение и сбор
    for (const м of this.монеты) {
      м.x -= this.скорость * dt;
      if (м.взята) continue;
      const cx = м.x + К.монеты.размер / 2, cy = зем - м.h;
      const дx = Math.abs(cx - (ИГРОК.x + ИГРОК.w / 2));
      const дy = Math.abs(cy - (зем - this.подъём - ИГРОК.h / 2));
      if (дx < ИГРОК.w / 2 + К.монеты.размер * 0.4 && дy < ИГРОК.h / 2 + К.монеты.размер * 0.4) {
        м.взята = true;
        this.монетСобрано++;
        this.суммаМонет += м.ценность;
        this.всплывашки.push({ x: cx, y: cy, text: `+${м.ценность}`, t: 0 });
        this.событие?.("монета");
      }
    }
    this.монеты = this.монеты.filter((м) => !м.взята && м.x > -60);

    // Всплывающие «+0.5»
    for (const в of this.всплывашки) { в.t += dt; в.y -= 40 * dt; }
    this.всплывашки = this.всплывашки.filter((в) => в.t < 0.8);
  }

  /** После столкновения: мир замирает, преследователь догоняет героиню. */
  обновитьКонец(dt: number) {
    this.послеКонца += dt;
    this.vy -= К.физика.гравитация * dt;
    this.подъём = Math.max(0, this.подъём + this.vy * dt);
    if (this.подъём === 0) this.vy = 0;
    for (const в of this.всплывашки) { в.t += dt; в.y -= 40 * dt; }
    this.всплывашки = this.всплывашки.filter((в) => в.t < 0.8);
  }

  private выбратьВидМонеты() {
    const виды = К.монеты.виды;
    let бросок = Math.random() * виды.reduce((s, v) => s + v.шанс, 0);
    for (const в of виды) { бросок -= в.шанс; if (бросок < 0) return в; }
    return виды[0];
  }

  /** Рисуем кадр. */
  рисовать(ctx: CanvasRenderingContext2D, фаза: Фаза) {
    const W = this.мирШирина, H = this.мирВысота, зем = this.земля;

    const небо = ctx.createLinearGradient(0, 0, 0, H);
    небо.addColorStop(0, "#0b1d2e"); небо.addColorStop(1, "#1f4256");
    ctx.fillStyle = небо; ctx.fillRect(0, 0, W, H);

    if (готова(фонИмг)) {
      const ширФона = H * фонИмг.naturalWidth / фонИмг.naturalHeight;
      const сдвигФона = ширФона > W ? this.смещениеФона % (ширФона - W) : 0;
      ctx.drawImage(фонИмг, -сдвигФона, 0, ширФона, H);
    }

    if (готова(дорогаИмг)) {
      const высотаДороги = К.вид.дорогаВысотаДоля * H;
      const ширДороги = высотаДороги * дорогаИмг.naturalWidth / дорогаИмг.naturalHeight;
      const верх = зем - К.вид.дорожкаДоля * высотаДороги;
      for (let x = -(this.смещение % ширДороги); x < W; x += ширДороги) {
        ctx.drawImage(дорогаИмг, x, верх, ширДороги, высотаДороги);
      }
    }

    for (const о of this.препятствия) {
      const img = барьеры[о.картинка];
      if (!готова(img)) continue;
      const ш = о.size * о.вытяжка[0], в = о.size * о.вытяжка[1];
      ctx.drawImage(img, о.x, зем - в + 4, ш, в);
    }

    for (const м of this.монеты) {
      const кач = Math.sin(this.время * 6 + м.x * 0.05) * 3;
      const р = К.монеты.размер;
      const img = м.emoji === "🪙" ? чипКартинка : подарокКартинка;
      if (img && готова(img)) ctx.drawImage(img, м.x, зем - м.h - р / 2 + кач, р, р);
      else эмодзи(ctx, м.emoji, м.x + р / 2, зем - м.h + р / 2 + кач, р);
    }

    const бег = фаза === "playing" && !this.закончена;
    const кач = (сдвиг: number) => (бег ? Math.abs(Math.sin(this.фазаБега + сдвиг)) * 4 : 0);
    const упала = this.закончена ? Math.min(1, this.послеКонца * 4) : 0;
    const догнал = this.закончена ? Math.min(1, this.послеКонца / 0.6) : 0;

    const hX = ИГРОК.x + ИГРОК.w / 2;
    const hY = зем - this.подъём - кач(0) + 4;
    const дистанция = К.погоня.дистанция;
    const преслX = hX - дистанция + догнал * (дистанция - 10);
    const hПресл = this.закончена ? 0 : (this.история[0]?.h ?? 0);
    const преслY = зем - hПресл - кач(1.5) + 4;
    спрайт(ctx, мэнИмг, преслX, преслY, ИГРОК.h);
    спрайт(ctx, ксюхаИмг, hX, hY, ИГРОК.h, упала * (Math.PI / 2));
    if (this.причина === "crash") эмодзи(ctx, "💥", hX + 20, зем - 10, 34);

    ctx.fillStyle = "rgba(255,255,255,0.8)";
    for (const с of this.снег) ctx.fillRect(с.x, с.y, с.r, с.r);

    // Всплывающие «+0.5»
    ctx.fillStyle = "#f4c430"; ctx.font = "bold 18px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    for (const в of this.всплывашки) { ctx.globalAlpha = Math.max(0, 1 - в.t / 0.8); ctx.fillText(в.text, в.x, в.y); }
    ctx.globalAlpha = 1;

    // Счёт и время (с учётом отступа под кнопки Telegram)
    if (фаза !== "menu") {
      const y0 = 12 + this.safeTopCss / this.масштаб;
      ctx.shadowColor = "rgba(0,0,0,0.6)"; ctx.shadowBlur = 4;
      ctx.fillStyle = "#ffffff"; ctx.font = "bold 20px sans-serif"; ctx.textBaseline = "top";
      ctx.textAlign = "left"; ctx.fillText(Т.игры.ksuha.худ.препятствий(this.пройдено), 14, y0);
      if (чипГотов()) { ctx.drawImage(чипКартинка!, 14, y0 + 26, 24, 24); ctx.fillText(Т.игры.ksuha.худ.монет(this.монетСобрано), 44, y0 + 26); }
      else ctx.fillText(Т.игры.ksuha.худ.монет(this.монетСобрано), 14, y0 + 26);
      if (this.лимит > 0) { ctx.textAlign = "right"; ctx.fillText(Т.игры.ksuha.худ.время(Math.ceil(this.осталось)), W - 14, y0); }
      ctx.shadowBlur = 0;
    }
  }
}

/** Награда за забег в фишках: препятствия + монеты, × сложность, × бонус «Повышение ЗП». */
export function посчитатьНаграду(пройдено: number, суммаМонет: number, сложность: КлючСложности, уровеньЗП: number) {
  const множитель = К.сложности[сложность].множительНаграды;
  const бонусПроц = бонусЗарплатыПроц({ salary_level: уровеньЗП });
  const заПрепятствия = пройдено / К.препятствийЗаФишку;
  const заМонеты = суммаМонет;
  const итого = Math.floor((заПрепятствия + заМонеты) * множитель * (1 + бонусПроц / 100) + 1e-9);
  return { заПрепятствия, заМонеты, множитель, бонусПроц, итого };
}
